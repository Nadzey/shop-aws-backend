const AWS = require("aws-sdk");
const s3 = new AWS.S3();
const csv = require("csv-parser");

module.exports.handler = async (event) => {
  try {
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Get bucket name and file key from S3 event
    const record = event.Records[0];
    const bucket = record.s3.bucket.name;
    const key = record.s3.object.key;

    console.log(`Fetching file from S3: ${bucket}/${key}`);

    // Read the CSV file from S3
    const s3Stream = s3
      .getObject({ Bucket: bucket, Key: key })
      .createReadStream();

    return new Promise((resolve, reject) => {
      let results = [];

      s3Stream
        .pipe(csv())
        .on("data", (row) => {
          console.log("Raw CSV Row:", row);

          // Ensure required fields exist before using them
          if (!row.Title || !row.Price || !row.Count) {
            console.warn("Skipping invalid row:", row);
            return;
          }

          // Convert values safely
          const product = {
            title: row.Title ? String(row.Title).trim() : "Unknown",
            description: row.Description
              ? String(row.Description).trim()
              : "No description",
            price: row.Price ? parseFloat(row.Price) : 0,
            count: row.Count ? parseInt(row.Count, 10) : 0,
          };

          console.log("Parsed product:", product);
          results.push(product);
        })
        .on("end", () => {
          console.log("CSV Parsing Complete. Processed rows:", results.length);
          resolve({
            statusCode: 200,
            body: JSON.stringify({
              message: "CSV processed successfully",
              products: results,
            }),
          });
        })
        .on("error", (error) => {
          console.error("CSV Parsing Error:", error);
          reject({
            statusCode: 500,
            body: JSON.stringify({
              error: "CSV Parsing Failed",
              details: error.message,
            }),
          });
        });
    });
  } catch (error) {
    console.error("Processing error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
