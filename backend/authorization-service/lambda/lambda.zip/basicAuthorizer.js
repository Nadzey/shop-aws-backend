module.exports.handler = async (event, context, cb) => {
  console.log("Event: ", JSON.stringify(event));

  if (!event.authorizationToken) {
    console.log("No Authorization header received.");
    return cb("Unauthorized");
  }

  try {
    // Extract Basic Auth credentials
    const tokenParts = event.authorizationToken.split(" ");
    if (tokenParts[0] !== "Basic" || !tokenParts[1]) {
      console.log("Invalid Authorization format.");
      return cb("Unauthorized");
    }

    // Decode Base64 credentials
    const decodedCredentials = Buffer.from(tokenParts[1], "base64").toString(
      "utf-8"
    );
    const [username, password] = decodedCredentials.split(":");

    console.log(`Received Username: ${username}`);
    console.log(`Received Password: ${password}`);

    // Check environment variable
    console.log(`Expected Username: Nadzey`);
    console.log(`Expected Password: ${process.env["Nadzey"]}`);

    const expectedPassword = process.env[username];

    if (!expectedPassword || expectedPassword !== password) {
      console.log("Invalid credentials.");
      return cb("Unauthorized");
    }

    console.log("Authorization successful!");

    // Generate IAM policy
    const policy = generatePolicy(username, event.methodArn, "Allow");
    return cb(null, policy);
  } catch (error) {
    console.log("Authorization Error: ", error.message);
    return cb("Unauthorized");
  }
};

// IAM Policy Generator
const generatePolicy = (principalId, resource, effect = "Allow") => {
  return {
    principalId: principalId,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: resource,
        },
      ],
    },
  };
};
